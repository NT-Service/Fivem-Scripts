ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('tax:picturemsg')
AddEventHandler('tax:picturemsg', function(icon, masg, titel, subtitle)

    showPictureNotification(icon, masg, titel, subtitle)

end)

function showPictureNotification(icon, msg, title, subtitle)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg);
    SetNotificationMessage(icon, icon, true, 1, title, subtitle);
    DrawNotification(false, true);
end