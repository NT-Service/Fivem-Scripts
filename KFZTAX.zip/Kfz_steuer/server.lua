ESX = exports['es_extended']:getSharedObject()


Citizen.CreateThread(function()

    while true do       
   
        for k, playerid in pairs(GetPlayers()) do
            local xPlayer = ESX.GetPlayerFromId(playerid)

            if xPlayer ~= nill then
                
                local vehicleCount = MySQL.Sync.fetchScalar("SELECT COUNT(plate) FROM owned_vehicles WHERE owner = @owner", 
                {
                    ["@owner"] = xPlayer.identifier,
                }
                )
            
                local tax = vehicleCount * 380
                xPlayer.removeAccountMoney('bank', tax)
                -- msg 
                TriggerClientEvent('tax:picturemsg', xPlayer.source, 'CHAR_LS_CUSTOMS', 'Du hast ~r~' .. tax .. '$ ~s~an ~o~Kfz-Steuern ~s~gezahlt', 'Finanzamt', 'Gebühren bezahlt')

            end
        end 
        
        Citizen.Wait(1800000)
    end

end)